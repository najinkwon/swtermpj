package com.example.swtermproject.ui.ingredient

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.swtermproject.R
import com.example.swtermproject.ocr.BReceiptItemCandidate
import com.example.swtermproject.ocr.BReceiptOcrManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AReceiptScanFragment : Fragment() {

    private var ocrManager: BReceiptOcrManager? = null

    private lateinit var btnStart: Button
    private lateinit var btnResult: Button

    private var isMovingToSampleResult = false

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) {
                Toast.makeText(
                    requireContext(),
                    "이미지 선택이 취소되었습니다",
                    Toast.LENGTH_SHORT
                ).show()
                return@registerForActivityResult
            }

            recognizeReceiptImage(uri)
        }

    private val cameraPreview =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
            if (bitmap == null) {
                Toast.makeText(
                    requireContext(),
                    "촬영이 취소되었습니다",
                    Toast.LENGTH_SHORT
                ).show()
                return@registerForActivityResult
            }

            recognizeReceiptBitmap(bitmap)
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                cameraPreview.launch(null)
            } else {
                Toast.makeText(
                    requireContext(),
                    "카메라 권한이 필요합니다",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(
            R.layout.fragment_receipt_scan,
            container,
            false
        )

        btnStart = view.findViewById(R.id.btnStartReceiptScan)
        btnResult = view.findViewById(R.id.btnReceiptResult)

        btnStart.backgroundTintList = null
        btnStart.setBackgroundResource(R.drawable.bg_primary_button)
        btnStart.setTextColor(
            ContextCompat.getColor(requireContext(), R.color.white)
        )

        btnResult.backgroundTintList = null
        btnResult.setBackgroundResource(R.drawable.bg_chip_white)
        btnResult.setTextColor(
            ContextCompat.getColor(requireContext(), R.color.primary_green_dark)
        )

        btnStart.setOnClickListener {
            showScanOptionDialog()
        }

        btnResult.setOnClickListener {
            openSampleResult()
        }

        return view
    }

    private fun getOcrManager(): BReceiptOcrManager {
        val existing = ocrManager

        if (existing != null) {
            return existing
        }

        val created = BReceiptOcrManager(
            requireContext().applicationContext
        )

        ocrManager = created
        return created
    }

    private fun openSampleResult() {
        if (isMovingToSampleResult) {
            return
        }

        isMovingToSampleResult = true
        btnResult.isEnabled = false

        val sampleCandidates = listOf(
                BReceiptItemCandidate(
                    name = "우유",
                    amountText = "1L",
                    amount = 1000.0,
                    unit = "ml",
                    amountGram = null,
                    category = "유제품",
                    amountSource = "sample"
                ),
                BReceiptItemCandidate(
                    name = "계란",
                    amountText = "10입",
                    amount = 10.0,
                    unit = "개",
                    amountGram = null,
                    category = "단백질",
                    amountSource = "sample"
                ),
                BReceiptItemCandidate(
                    name = "바나나",
                    amountText = "1송이",
                    amount = 1.0,
                    unit = "개",
                    amountGram = null,
                    category = "과일",
                    amountSource = "sample"
                )
            )

            moveToResult(sampleCandidates)
    }

    private fun showScanOptionDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("영수증 인식")
            .setItems(
                arrayOf(
                    "카메라로 촬영",
                    "갤러리에서 선택"
                )
            ) { _, which ->
                when (which) {
                    0 -> startCamera()
                    1 -> imagePicker.launch("image/*")
                }
            }
            .show()
    }

    private fun startCamera() {
        val permission = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.CAMERA
        )

        if (permission == PackageManager.PERMISSION_GRANTED) {
            cameraPreview.launch(null)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun recognizeReceiptImage(uri: Uri) {
        setLoading(true)

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                getOcrManager().recognizeTextFromImage(uri)
            }

            handleOcrResult(result)
        }
    }

    private fun recognizeReceiptBitmap(bitmap: Bitmap) {
        setLoading(true)

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                getOcrManager().recognizeTextFromBitmap(bitmap)
            }

            handleOcrResult(result)
        }
    }

    private fun handleOcrResult(result: Result<String>) {
        result.onSuccess { rawText ->
            val candidates = getOcrManager()
                .extractItemsFromText(rawText)
                .filter { it.name.isNotBlank() }
                .distinctBy { it.name }
                .take(12)

            if (candidates.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "인식된 재료 후보가 없습니다",
                    Toast.LENGTH_SHORT
                ).show()

                setLoading(false)
            } else {
                setLoading(false)
                moveToResult(candidates)
            }
        }.onFailure {
            Toast.makeText(
                requireContext(),
                it.message ?: "OCR 인식에 실패했습니다",
                Toast.LENGTH_SHORT
            ).show()

            setLoading(false)
        }
    }

    private fun setLoading(isLoading: Boolean) {
        btnStart.isEnabled = !isLoading
        btnResult.isEnabled = !isLoading

        btnStart.text =
            if (isLoading) {
                "영수증 인식 중..."
            } else {
                "영수증 인식 시작"
            }
    }

    private fun moveToResult(candidates: List<BReceiptItemCandidate>) {
        if (!isAdded) {
            isMovingToSampleResult = false
            btnResult.isEnabled = true
            return
        }

        runCatching {
            parentFragmentManager.beginTransaction()
                .replace(
                    R.id.fragmentContainer,
                    AReceiptResultFragment.newInstanceFromCandidates(candidates)
                )
                .addToBackStack(null)
                .commit()
        }.onFailure {
            isMovingToSampleResult = false
            btnResult.isEnabled = true

            Toast.makeText(
                requireContext(),
                "결과 화면으로 이동하지 못했어요",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
