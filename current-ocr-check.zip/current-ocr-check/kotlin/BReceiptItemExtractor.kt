package com.example.swtermproject.ocr

object BReceiptItemExtractor {

    private data class IngredientRule(
        val canonical: String,
        val category: String,
        val aliases: List<String>,
        val defaultUnit: String = "개"
    )

    private val rules = listOf(
        IngredientRule("우유", "유제품", listOf("우유", "서울우유", "매일우유", "남양우유", "milk"), "ml"),
        IngredientRule("치즈", "유제품", listOf("치즈", "체다치즈", "모짜렐라", "슬라이스치즈"), "개"),
        IngredientRule("버터", "유제품", listOf("버터"), "g"),
        IngredientRule("요거트", "유제품", listOf("요거트", "요구르트", "그릭요거트"), "개"),

        IngredientRule("계란", "단백질", listOf("계란", "달걀", "특란", "왕란", "유정란"), "개"),
        IngredientRule("두부", "단백질", listOf("두부", "찌개두부", "부침두부", "순두부"), "개"),
        IngredientRule("닭가슴살", "단백질", listOf("닭가슴살", "가슴살", "닭가슴"), "g"),
        IngredientRule("닭고기", "단백질", listOf("닭고기", "닭다리", "닭안심", "닭봉", "닭날개"), "g"),
        IngredientRule("돼지고기", "단백질", listOf("돼지고기", "삼겹살", "목살", "앞다리살", "뒷다리살"), "g"),
        IngredientRule("소고기", "단백질", listOf("소고기", "쇠고기", "한우", "불고기"), "g"),
        IngredientRule("참치", "단백질", listOf("참치", "참치캔"), "개"),
        IngredientRule("햄", "단백질", listOf("햄", "스팸", "베이컨", "소시지", "소세지"), "g"),

        IngredientRule("양파", "채소", listOf("양파", "깐양파"), "개"),
        IngredientRule("대파", "채소", listOf("대파", "쪽파", "실파"), "개"),
        IngredientRule("마늘", "채소", listOf("마늘", "깐마늘", "다진마늘"), "g"),
        IngredientRule("상추", "채소", listOf("상추", "청상추", "적상추"), "개"),
        IngredientRule("양상추", "채소", listOf("양상추"), "개"),
        IngredientRule("양배추", "채소", listOf("양배추", "적양배추"), "개"),
        IngredientRule("콩나물", "채소", listOf("콩나물", "숙주", "숙주나물"), "g"),
        IngredientRule("오이", "채소", listOf("오이"), "개"),
        IngredientRule("당근", "채소", listOf("당근"), "개"),
        IngredientRule("감자", "채소", listOf("감자"), "개"),
        IngredientRule("고구마", "채소", listOf("고구마"), "개"),
        IngredientRule("버섯", "채소", listOf("버섯", "새송이버섯", "느타리버섯", "팽이버섯", "표고버섯"), "g"),
        IngredientRule("토마토", "채소", listOf("토마토", "방울토마토"), "개"),

        IngredientRule("바나나", "기타", listOf("바나나"), "개"),
        IngredientRule("사과", "기타", listOf("사과"), "개"),
        IngredientRule("딸기", "기타", listOf("딸기"), "g"),

        IngredientRule("밥", "기타", listOf("밥", "즉석밥", "햇반"), "개"),
        IngredientRule("식빵", "기타", listOf("식빵", "빵", "샌드위치빵"), "개"),
        IngredientRule("라면", "기타", listOf("라면", "봉지라면", "컵라면"), "개"),
        IngredientRule("파스타면", "기타", listOf("파스타면", "스파게티면", "면"), "g"),
        IngredientRule("쌀", "기타", listOf("쌀", "백미", "현미"), "g"),

        IngredientRule("간장", "조미료/소스", listOf("간장", "진간장", "양조간장", "국간장"), "ml"),
        IngredientRule("고추장", "조미료/소스", listOf("고추장"), "g"),
        IngredientRule("된장", "조미료/소스", listOf("된장"), "g"),
        IngredientRule("참기름", "조미료/소스", listOf("참기름"), "ml"),
        IngredientRule("식용유", "조미료/소스", listOf("식용유", "올리브유", "카놀라유"), "ml"),
        IngredientRule("소금", "조미료/소스", listOf("소금"), "g"),
        IngredientRule("설탕", "조미료/소스", listOf("설탕"), "g"),
        IngredientRule("후추", "조미료/소스", listOf("후추", "후춧가루"), "g"),
        IngredientRule("마요네즈", "조미료/소스", listOf("마요네즈", "마요"), "g"),
        IngredientRule("케첩", "조미료/소스", listOf("케첩", "케찹"), "g"),
        IngredientRule("소스", "조미료/소스", listOf("소스", "드레싱"), "g"),
        IngredientRule("카레", "조미료/소스", listOf("카레"), "g")
    )

    private val ignoredKeywords = listOf(
        "합계", "소계", "카드", "승인", "영수증", "부가세", "과세", "면세",
        "거스름돈", "전화", "사업자", "대표", "주소", "일시", "금액", "수량",
        "단가", "결제", "포인트", "적립", "쿠폰", "할인", "매장", "고객",
        "바코드", "품번", "상품코드", "판매", "계산원", "봉투", "재사용",
        "교환", "환불", "영업", "문의", "주문", "배달", "주차", "원산지"
    )

    fun extractCandidates(lines: List<String>): List<BReceiptItemCandidate> {
        return lines
            .flatMap { extractCandidatesFromLine(it) }
            .distinctBy { it.name }
            .take(8)
    }

    private fun extractCandidatesFromLine(rawLine: String): List<BReceiptItemCandidate> {
        val line = normalizeLine(rawLine)

        if (line.length < 2) {
            return emptyList()
        }

        if (ignoredKeywords.any { line.contains(it) }) {
            return emptyList()
        }

        if (looksLikeOnlyNumberOrCode(line)) {
            return emptyList()
        }

        val matchedRules = rules.filter { rule ->
            rule.aliases.any { alias ->
                line.contains(alias, ignoreCase = true)
            }
        }

        if (matchedRules.isEmpty()) {
            return emptyList()
        }

        val amountInfo = extractAmount(rawLine)

        return matchedRules.map { rule ->
            BReceiptItemCandidate(
                name = rule.canonical,
                amountText = amountInfo?.rawText,
                amount = amountInfo?.amount,
                unit = amountInfo?.unit ?: rule.defaultUnit,
                amountGram = if (amountInfo?.unit == "g") amountInfo.amount else null,
                category = rule.category,
                amountSource = if (amountInfo == null) "ocr-default" else "ocr"
            )
        }
    }

    private data class AmountInfo(
        val rawText: String,
        val amount: Double,
        val unit: String
    )

    private fun extractAmount(text: String): AmountInfo? {
        val regex = Regex(
            "(\\d+(?:\\.\\d+)?)\\s*(kg|g|ml|mL|ML|l|L|개|입|봉|팩|병|통|캔|알)",
            RegexOption.IGNORE_CASE
        )

        val match = regex.find(text) ?: return null

        val value = match.groupValues[1].toDoubleOrNull() ?: return null
        val rawUnit = match.groupValues[2]

        val unit = when (rawUnit.lowercase()) {
            "kg" -> "g"
            "l" -> "ml"
            "입" -> "개"
            else -> rawUnit.lowercase()
        }

        val amount = when (rawUnit.lowercase()) {
            "kg" -> value * 1000.0
            "l" -> value * 1000.0
            else -> value
        }

        return AmountInfo(
            rawText = match.value,
            amount = amount,
            unit = unit
        )
    }

    private fun normalizeLine(text: String): String {
        return text
            .replace(Regex("[^가-힣a-zA-Z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun looksLikeOnlyNumberOrCode(text: String): Boolean {
        val noSpace = text.replace("\\s".toRegex(), "")
        if (noSpace.all { it.isDigit() }) {
            return true
        }

        if (Regex("^[0-9A-Za-z]{5,}$").matches(noSpace)) {
            return true
        }

        if (Regex("^\\d{2,}\\s+\\d{2,}.*").matches(text)) {
            return true
        }

        return false
    }
}
