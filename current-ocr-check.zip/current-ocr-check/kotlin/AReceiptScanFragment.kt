package com.example.swtermproject.ui.ingredient

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.swtermproject.R
import com.example.swtermproject.ocr.BReceiptItemCandidate
import com.example.swtermproject.ocr.BReceiptOcrManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AReceiptScanFragment : Fragment() {

    private var ocrManager: BReceiptOcrManager? = null

    private lateinit var btnStart: Button
    private lateinit var btnResult: Button

    private var isMovingToSampleResult = false

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) {
                Toast.makeText(
                    requireContext(),
                    "이미지 선택이 취소되었습니다",
                    Toast.LENGTH_SHORT
                ).show()
                return@registerForActivityResult
            }

            recognizeReceiptImage(uri)
        }

    private val cameraPreview =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
            if (bitmap == null) {
                Toast.makeText(
                    requireContext(),
                    "촬영이 취소되었습니다",
                    Toast.LENGTH_SHORT
                ).show()
                return@registerForActivityResult
            }

            recognizeReceiptBitmap(bitmap)
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                cameraPreview.launch(null)
            } else {
                Toast.makeText(
                    requireContext(),
                    "카메라 권한이 필요합니다",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(
            R.layout.fragment_receipt_scan,
            container,
            false
        )

        btnStart = view.findViewById(R.id.btnStartReceiptScan)
        btnResult = view.findViewById(R.id.btnReceiptResult)

        btnStart.backgroundTintList = null
        btnStart.setBackgroundResource(R.drawable.bg_primary_button)
        btnStart.setTextColor(
            ContextCompat.getColor(requireContext(), R.color.white)
        )

        btnResult.backgroundTintList = null
        btnResult.setBackgroundResource(R.drawable.bg_chip_white)
        btnResult.setTextColor(
            ContextCompat.getColor(requireContext(), R.color.primary_green_dark)
        )

        btnStart.setOnClickListener {
            showScanOptionDialog()
        }

        btnResult.setOnClickListener {
            openSampleResult()
        }

        return view
    }

    private fun getOcrManager(): BReceiptOcrManager {
        val existing = ocrManager

        if (existing != null) {
            return existing
        }

        val created = BReceiptOcrManager(
            requireContext().applicationContext
        )

        ocrManager = created
        return created
    }

    private fun openSampleResult() {
        if (isMovingToSampleResult) {
            return
        }

        isMovingToSampleResult = true
        btnResult.isEnabled = false

        val sampleCandidates = listOf(
                BReceiptItemCandidate(
                    name = "우유",
                    amountText = "1L",
                    amount = 1000.0,
                    unit = "ml",
                    amountGram = null,
                    category = "유제품",
                    amountSource = "sample"
                ),
                BReceiptItemCandidate(
                    name = "계란",
                    amountText = "10입",
                    amount = 10.0,
                    unit = "개",
                    amountGram = null,
                    category = "단백질",
                    amountSource = "sample"
                ),
                BReceiptItemCandidate(
                    name = "바나나",
                    amountText = "1송이",
                    amount = 1.0,
                    unit = "개",
                    amountGram = null,
                    category = "과일",
                    amountSource = "sample"
                )
            )

            moveToResult(sampleCandidates)
    }

    private fun showScanOptionDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("영수증 인식")
            .setItems(
                arrayOf(
                    "카메라로 촬영",
                    "갤러리에서 선택"
                )
            ) { _, which ->
                when (which) {
                    0 -> startCamera()
                    1 -> imagePicker.launch("image/*")
                }
            }
            .show()
    }

    private fun startCamera() {
        val permission = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.CAMERA
        )

        if (permission == PackageManager.PERMISSION_GRANTED) {
            cameraPreview.launch(null)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun recognizeReceiptImage(uri: Uri) {
        setLoading(true)

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                getOcrManager().recognizeTextFromImage(uri)
            }

            handleOcrResult(result)
        }
    }

    private fun recognizeReceiptBitmap(bitmap: Bitmap) {
        setLoading(true)

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                getOcrManager().recognizeTextFromBitmap(bitmap)
            }

            handleOcrResult(result)
        }
    }

    private fun handleOcrResult(result: Result<String>) {
        result.onSuccess { rawText ->
            val candidates = extractSafeReceiptCandidates(rawText)

            if (candidates.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "인식된 재료 후보가 없습니다",
                    Toast.LENGTH_SHORT
                ).show()

                setLoading(false)
            } else {
                setLoading(false)
                moveToResult(candidates)
            }
        }.onFailure {
            Toast.makeText(
                requireContext(),
                it.message ?: "OCR 인식에 실패했습니다",
                Toast.LENGTH_SHORT
            ).show()

            setLoading(false)
        }
    }


    private data class SafeReceiptRule(
        val name: String,
        val category: String,
        val unit: String,
        val aliases: List<String>
    )

    private data class SafeReceiptAmount(
        val text: String,
        val amount: Double,
        val unit: String
    )

    private fun extractSafeReceiptCandidates(rawText: String): List<BReceiptItemCandidate> {
        val result = linkedMapOf<String, BReceiptItemCandidate>()

        rawText
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach { line ->
                if (shouldIgnoreReceiptLine(line)) {
                    return@forEach
                }

                val compactLine = line
                    .replace("\\s".toRegex(), "")
                    .lowercase()

                safeReceiptRules().forEach { rule ->
                    val matched = rule.aliases.any { alias ->
                        compactLine.contains(
                            alias.replace("\\s".toRegex(), "").lowercase()
                        )
                    }

                    if (matched && !result.containsKey(rule.name)) {
                        val amount = extractSafeReceiptAmount(line, rule.unit)

                        result[rule.name] = BReceiptItemCandidate(
                            name = rule.name,
                            amountText = amount.text,
                            amount = amount.amount,
                            unit = amount.unit,
                            amountGram = if (amount.unit == "g") amount.amount else null,
                            category = rule.category,
                            amountSource = "ocr-safe"
                        )
                    }
                }
            }

        return result.values.toList().take(8)
    }

    private fun safeReceiptRules(): List<SafeReceiptRule> {
        return listOf(
            SafeReceiptRule("우유", "유제품", "ml", listOf("우유")),
            SafeReceiptRule("치즈", "유제품", "개", listOf("치즈", "체다치즈", "모짜렐라치즈", "슬라이스치즈")),
            SafeReceiptRule("버터", "유제품", "g", listOf("버터")),
            SafeReceiptRule("요거트", "유제품", "개", listOf("요거트", "요구르트")),

            SafeReceiptRule("계란", "단백질", "개", listOf("계란", "달걀", "특란", "왕란", "유정란")),
            SafeReceiptRule("두부", "단백질", "개", listOf("두부", "찌개두부", "부침두부", "순두부")),
            SafeReceiptRule("닭가슴살", "단백질", "g", listOf("닭가슴살", "가슴살")),
            SafeReceiptRule("햄", "단백질", "g", listOf("햄", "스팸", "베이컨", "소시지", "소세지")),
            SafeReceiptRule("참치", "단백질", "개", listOf("참치", "참치캔")),

            SafeReceiptRule("양파", "채소", "개", listOf("양파")),
            SafeReceiptRule("대파", "채소", "개", listOf("대파", "쪽파", "실파")),
            SafeReceiptRule("마늘", "채소", "g", listOf("마늘", "다진마늘", "깐마늘")),
            SafeReceiptRule("상추", "채소", "개", listOf("상추")),
            SafeReceiptRule("콩나물", "채소", "g", listOf("콩나물", "숙주")),
            SafeReceiptRule("오이", "채소", "개", listOf("오이")),
            SafeReceiptRule("당근", "채소", "개", listOf("당근")),
            SafeReceiptRule("감자", "채소", "개", listOf("감자")),
            SafeReceiptRule("토마토", "채소", "개", listOf("토마토", "방울토마토")),
            SafeReceiptRule("버섯", "채소", "g", listOf("버섯", "새송이버섯", "느타리버섯", "팽이버섯")),

            SafeReceiptRule("바나나", "기타", "개", listOf("바나나")),
            SafeReceiptRule("사과", "기타", "개", listOf("사과")),
            SafeReceiptRule("식빵", "기타", "개", listOf("식빵")),
            SafeReceiptRule("밥", "기타", "개", listOf("밥", "즉석밥", "햇반")),
            SafeReceiptRule("라면", "기타", "개", listOf("라면")),
            SafeReceiptRule("쌀", "기타", "g", listOf("쌀", "백미", "현미")),

            SafeReceiptRule("간장", "조미료/소스", "ml", listOf("간장", "진간장", "양조간장", "국간장")),
            SafeReceiptRule("고추장", "조미료/소스", "g", listOf("고추장")),
            SafeReceiptRule("된장", "조미료/소스", "g", listOf("된장")),
            SafeReceiptRule("참기름", "조미료/소스", "ml", listOf("참기름")),
            SafeReceiptRule("식용유", "조미료/소스", "ml", listOf("식용유", "올리브유", "카놀라유")),
            SafeReceiptRule("소금", "조미료/소스", "g", listOf("소금")),
            SafeReceiptRule("설탕", "조미료/소스", "g", listOf("설탕")),
            SafeReceiptRule("후추", "조미료/소스", "g", listOf("후추")),
            SafeReceiptRule("마요네즈", "조미료/소스", "g", listOf("마요네즈", "마요")),
            SafeReceiptRule("케첩", "조미료/소스", "g", listOf("케첩", "케찹"))
        )
    }

    private fun shouldIgnoreReceiptLine(line: String): Boolean {
        val compact = line
            .replace("\\s".toRegex(), "")
            .lowercase()

        if (compact.length < 2) {
            return true
        }

        if (compact.all { it.isDigit() }) {
            return true
        }

        val ignored = listOf(
            "합계", "소계", "카드", "승인", "영수증", "부가세", "과세", "면세",
            "거스름돈", "전화", "사업자", "대표", "주소", "일시", "금액",
            "결제", "포인트", "적립", "쿠폰", "매장", "고객", "바코드",
            "품번", "상품코드", "판매", "계산원", "봉투", "교환", "환불",
            "영업", "문의", "주문", "배달", "주차"
        )

        return ignored.any { compact.contains(it.lowercase()) }
    }

    private fun extractSafeReceiptAmount(
        line: String,
        defaultUnit: String
    ): SafeReceiptAmount {
        val match = Regex(
            "(\\d+(?:\\.\\d+)?)\\s*(kg|g|ml|mL|ML|l|L|개|입|봉|팩|병|통|캔|알|송이)",
            RegexOption.IGNORE_CASE
        ).find(line)

        if (match == null) {
            return SafeReceiptAmount(
                text = "1$defaultUnit",
                amount = 1.0,
                unit = defaultUnit
            )
        }

        val value = match.groupValues[1].toDoubleOrNull() ?: 1.0
        val rawUnit = match.groupValues[2]
        val loweredUnit = rawUnit.lowercase()

        val unit = when (loweredUnit) {
            "kg" -> "g"
            "l" -> "ml"
            "입" -> "개"
            "송이" -> "개"
            else -> loweredUnit
        }

        val amount = when (loweredUnit) {
            "kg" -> value * 1000.0
            "l" -> value * 1000.0
            else -> value
        }

        return SafeReceiptAmount(
            text = "${formatSafeReceiptAmount(amount)}$unit",
            amount = amount,
            unit = unit
        )
    }

    private fun formatSafeReceiptAmount(value: Double): String {
        return if (value % 1.0 == 0.0) {
            value.toInt().toString()
        } else {
            value.toString()
        }
    }


    private fun setLoading(isLoading: Boolean) {
        btnStart.isEnabled = !isLoading
        btnResult.isEnabled = !isLoading

        btnStart.text =
            if (isLoading) {
                "영수증 인식 중..."
            } else {
                "영수증 인식 시작"
            }
    }

    private fun moveToResult(candidates: List<BReceiptItemCandidate>) {
        if (!isAdded) {
            isMovingToSampleResult = false
            btnResult.isEnabled = true
            return
        }

        runCatching {
            parentFragmentManager.beginTransaction()
                .replace(
                    R.id.fragmentContainer,
                    AReceiptResultFragment.newInstanceFromCandidates(candidates)
                )
                .addToBackStack(null)
                .commit()
        }.onFailure {
            isMovingToSampleResult = false
            btnResult.isEnabled = true

            Toast.makeText(
                requireContext(),
                "결과 화면으로 이동하지 못했어요",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
